
"""
Chrome Takeover Mode - Playwright CDP
Start Chrome: chrome --remote-debugging-port=9222 --user-data-dir=/tmp/chrome-arb
pip install playwright && playwright install chromium
"""
from playwright.sync_api import sync_playwright
import time, os

DESIGNATED_AMOUNT = os.getenv("DESIGNATED_AMOUNT_USD", "100")

class ChromeTakeover:
    def __init__(self, cdp_url="http://localhost:9222"):
        self.cdp_url = cdp_url
        self.playwright = None
        self.browser = None

    def connect(self):
        self.playwright = sync_playwright().start()
        self.browser = self.playwright.chromium.connect_over_cdp(self.cdp_url)
        # Use first context
        self.context = self.browser.contexts[0] if self.browser.contexts else None
        if not self.context:
            raise Exception("No browser context found - make sure Chrome is running with --remote-debugging-port")
        print(f"Connected to Chrome with {len(self.context.pages)} pages")

    def find_or_create_page(self, domain):
        for p in self.context.pages:
            if domain in p.url:
                return p
        # Create new page if not found
        page = self.context.new_page()
        page.goto(f"https://{domain}.com")
        return page

    def buy_kalshi(self, ticker, amount_usd=None, side="yes"):
        amount_usd = amount_usd or DESIGNATED_AMOUNT
        page = self.find_or_create_page("kalshi")
        # Check kill switch file
        if os.path.exists("/tmp/kill-switch"):
            print("Kill switch active, aborting")
            return False
            
        page.goto(f"https://kalshi.com/markets/{ticker}", wait_until="domcontentloaded")
        time.sleep(1)
        # Try multiple selectors (sites change)
        try:
            # Click side
            page.click(f'button:has-text("Buy {side}")', timeout=5000)
        except:
            try:
                page.click(f'[data-testid="buy-{side}-button"]', timeout=5000)
            except Exception as e:
                page.screenshot(path="/tmp/kalshi_error.png")
                print(f"Failed to find buy button: {e}")
                return False
        
        time.sleep(0.5)
        # Fill amount
        try:
            page.fill('input[name="count"]', str(amount_usd))
        except:
            page.fill('input[type="number"]', str(amount_usd))
        
        page.click('button:has-text("Submit")')
        try:
            page.wait_for_selector('text=Order Confirmed', timeout=10000)
            print(f"[KALSHI] Bought {ticker} {side} ${amount_usd}")
            return True
        except:
            page.screenshot(path="/tmp/kalshi_submit_error.png")
            return False

    def buy_polymarket(self, market_url, amount_usd=None, outcome="Yes"):
        amount_usd = amount_usd or DESIGNATED_AMOUNT
        page = self.find_or_create_page("polymarket")
        
        if os.path.exists("/tmp/kill-switch"):
            return False
            
        page.goto(market_url, wait_until="domcontentloaded")
        time.sleep(1)
        try:
            page.click(f'button:has-text("Buy {outcome}")', timeout=5000)
            time.sleep(0.5)
            page.fill('input[placeholder="Amount"]', str(amount_usd))
            page.click('button:has-text("Buy")', timeout=5000)
            page.wait_for_selector('text=Trade Executed', timeout=10000)
            print(f"[POLY] Bought {market_url} {outcome} ${amount_usd}")
            return True
        except Exception as e:
            page.screenshot(path="/tmp/poly_error.png")
            print(f"Poly buy failed: {e}")
            return False

    def execute_arb(self, arb, amount=None):
        amount = amount or DESIGNATED_AMOUNT
        print(f"Executing arb {arb['pairId']} for ${amount}")
        # Execute smaller liquidity first
        leg1 = arb['legA']
        leg2 = arb['legB']
        
        # leg1
        ok1 = self.buy_kalshi(arb['kalshi_ticker'], amount, leg1['side'].lower()) if leg1['venue']=='kalshi' else self.buy_polymarket(arb['poly_url'], amount, leg1['side'])
        if not ok1:
            return {"status": "aborted", "reason": "leg1 failed"}
        
        # leg2 immediately
        ok2 = self.buy_kalshi(arb['kalshi_ticker'], amount, leg2['side'].lower()) if leg2['venue']=='kalshi' else self.buy_polymarket(arb['poly_url'], amount, leg2['side'])
        if not ok2:
            print("LEG2 FAILED - MANUAL UNWIND REQUIRED!")
            return {"status": "unwound_needed", "reason": "leg2 failed after leg1 filled"}
        
        return {"status": "filled"}

if __name__ == "__main__":
    bot = ChromeTakeover()
    bot.connect()
    # Test
    # bot.buy_kalshi("FED-24JUL-NOCHANGE", 10, "yes")
