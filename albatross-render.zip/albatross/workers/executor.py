
"""
Atomic Executor - API First
"""
import os, asyncio, json
from dotenv import load_dotenv
load_dotenv()

DESIGNATED_AMOUNT = float(os.getenv("DESIGNATED_AMOUNT_USD", "100"))
EXEC_ENABLED = os.getenv("EXECUTION_ENABLED", "false").lower() == "true"

class AtomicExecutor:
    def __init__(self):
        # Import here so file still loads without keys
        self.kalshi_key = os.getenv("KALSHI_API_KEY")
        self.kalshi_secret = os.getenv("KALSHI_API_SECRET")
        self.poly_key = os.getenv("POLYMARKET_PRIVATE_KEY")
        
    async def check_balances(self, amount):
        # TODO: Call Kalshi GET /portfolio/balance and Polymarket balance
        # For now return True
        return True

    async def place_order_kalshi(self, leg, size):
        import requests, base64, hmac, hashlib, time
        # Simplified - use official kalshi-python SDK in production
        # pip install kalshi
        print(f"[KALSHI] Placing {leg} size {size}")
        # Mock filled for demo
        return {"filled": True, "order_id": "kalshi_123", "venue": "kalshi"}

    async def place_order_polymarket(self, leg, size):
        # Use py-clob-client
        # from py_clob_client.client import ClobClient
        # client = ClobClient("https://clob.polymarket.com", chain_id=137, key=self.poly_key)
        print(f"[POLY] Placing {leg} size {size}")
        return {"filled": True, "order_id": "poly_123", "venue": "polymarket"}

    async def place_order(self, leg, size):
        if leg['venue'] == 'kalshi':
            return await self.place_order_kalshi(leg, size)
        else:
            return await self.place_order_polymarket(leg, size)

    async def unwind(self, leg, size):
        print(f"EMERGENCY UNWIND {leg}")
        # Place opposite side market order
        return True

    async def execute(self, arb):
        if not EXEC_ENABLED:
            print(f"[DRY RUN] Would buy {arb}")
            return {"status": "dry_run", "arb": arb}

        size = min(DESIGNATED_AMOUNT, arb.get('maxSize', DESIGNATED_AMOUNT))
        
        # Check kill switch via Redis
        # if redis.get("execution:kill"): return {"status": "killed"}

        leg1, leg2 = (arb['legA'], arb['legB']) if arb['legA'].get('depth', 0) < arb['legB'].get('depth', 0) else (arb['legB'], arb['legA'])

        try:
            o1 = await self.place_order(leg1, size)
            if not o1['filled']:
                return {"status": "aborted", "reason": "leg1 not filled"}

            o2 = await self.place_order(leg2, size)
            if not o2['filled']:
                await self.unwind(leg1, size)
                return {"status": "unwound", "reason": "leg2 failed"}

            return {"status": "filled", "profit": arb['edgeNet'] * size, "orders": [o1, o2]}
        except Exception as e:
            await self.unwind(leg1, size)
            raise e

if __name__ == "__main__":
    import asyncio
    ex = AtomicExecutor()
    test_arb = {
        "pairId": "test", "edgeNet": 0.03, "maxSize": 100,
        "legA": {"venue": "kalshi", "side": "YES", "price": 0.42, "depth": 50},
        "legB": {"venue": "polymarket", "side": "NO", "price": 0.54, "depth": 100}
    }
    print(asyncio.run(ex.execute(test_arb)))
