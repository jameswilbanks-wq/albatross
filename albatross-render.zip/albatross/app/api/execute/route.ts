
import { NextResponse } from 'next/server';

export async function POST(req: Request) {
  const body = await req.json();
  const { pairId, size, legs, mode } = body;

  // Check kill switch
  // const redis = await getRedis();
  // if (await redis.get('execution:kill')) return NextResponse.json({ status: 'killed' }, {status: 403});

  console.log(`[EXECUTE] ${pairId} size ${size} mode ${mode}`, legs);

  // In production, call Python executor service:
  // const res = await fetch('http://localhost:8001/execute', { method: 'POST', body: JSON.stringify(body) });

  // Mock for now
  if (process.env.EXECUTION_ENABLED !== 'true') {
    return NextResponse.json({ status: 'dry_run', message: `Would buy ${size} of ${pairId}`, legs });
  }

  return NextResponse.json({ status: 'filled', pairId, size, pnl: 0.03 * size });
}
