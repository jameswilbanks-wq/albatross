
import { NextResponse } from 'next/server';

// Placeholder - in prod, read from Redis/Supabase
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const minEdge = parseFloat(searchParams.get('minEdge') || '0.02');
  return NextResponse.json({ opportunities: [], minEdge, note: "Wire to Redis in production" });
}
