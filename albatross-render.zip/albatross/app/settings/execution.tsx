
'use client';
import { useState } from 'react';

export default function ExecutionSettings() {
  const [enabled, setEnabled] = useState(false);
  const [amount, setAmount] = useState(100);
  const [mode, setMode] = useState<'api'|'chrome'>('api');

  return (
    <div className="border border-zinc-800 rounded-xl p-6 bg-zinc-900/50 max-w-xl">
      <h2 className="text-xl font-bold mb-4">⚡ Auto-Execution</h2>
      
      <div className="space-y-4">
        <label className="flex items-center justify-between">
          <span>Enable Auto-Buy</span>
          <input type="checkbox" checked={enabled} onChange={e=>setEnabled(e.target.checked)} className="w-12 h-6" />
        </label>

        <label className="block">
          <span className="text-sm text-zinc-400">Designated Amount per Leg (USD)</span>
          <input type="number" value={amount} onChange={e=>setAmount(parseFloat(e.target.value))} 
            className="w-full mt-1 bg-black border border-zinc-700 rounded px-3 py-2 font-mono" />
          <span className="text-xs text-zinc-500">Bot will buy ${amount} on Kalshi + ${amount} on Polymarket = ${amount*2} total capital per arb</span>
        </label>

        <label className="block">
          <span className="text-sm text-zinc-400">Execution Mode</span>
          <select value={mode} onChange={e=>setMode(e.target.value as any)} className="w-full mt-1 bg-black border border-zinc-700 rounded px-3 py-2">
            <option value="api">API (Recommended - Fast, Reliable)</option>
            <option value="chrome">Chrome Takeover (Fallback - Clicks your browser)</option>
          </select>
        </label>

        {mode === 'chrome' && (
          <div className="bg-yellow-900/30 border border-yellow-700 rounded p-3 text-sm">
            <b>Chrome Mode Setup:</b><br/>
            1. Close Chrome<br/>
            2. Run: <code className="bg-black px-1">chrome --remote-debugging-port=9222 --user-data-dir=/tmp/chrome-arb</code><br/>
            3. Login to Kalshi & Polymarket in that window<br/>
            4. Keep window open
          </div>
        )}

        <div className="flex gap-2 pt-2">
          <button className="bg-white text-black px-4 py-2 rounded font-semibold">Save Settings</button>
          <button className="bg-red-600 px-4 py-2 rounded">🛑 KILL SWITCH</button>
          <button className="border border-zinc-700 px-4 py-2 rounded">Test Dry Run</button>
        </div>

        <div className="text-xs text-zinc-500 pt-4 border-t border-zinc-800">
          Risk: Legging risk exists. If leg1 fills and leg2 fails, bot will attempt unwind. Use at own risk. Start with $10.
        </div>
      </div>
    </div>
  );
}
