import { ArbOpportunity } from './arb-engine';

export interface ExecutionConfig {
  enabled: boolean;
  designatedAmountUsd: number;
  mode: 'api' | 'chrome';
  maxSlippageBps: number;
}

export async function executeArb(arb: ArbOpportunity, config: ExecutionConfig) {
  if (!config.enabled) {
    console.log('[DRY RUN] Would execute:', arb, 'amount', config.designatedAmountUsd);
    return { status: 'dry_run', arb };
  }

  const size = Math.min(config.designatedAmountUsd, arb.maxSize);

  // Re-quote check
  const fresh = await fetch(`/api/markets/${arb.pairId}/quote`).then(r => r.json()).catch(()=>null);
  if (fresh) {
    const freshEdge = 1 - (fresh.yesAsk + fresh.noAsk);
    if (freshEdge * 10000 < (arb.edgeNet * 10000 - config.maxSlippageBps)) {
      return { status: 'aborted', reason: 'slippage - edge gone' };
    }
  }

  const res = await fetch('/api/execute', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ pairId: arb.pairId, size, legs: [arb.legA, arb.legB], mode: config.mode })
  });

  return res.json();
}
