import { describe, it, expect } from 'vitest';
import { kalshiTakerFee, polymarketTakerFee, totalFees } from './fees';

describe('kalshiTakerFee', () => {
  it('is 0 at price = 0', () => {
    expect(kalshiTakerFee(0)).toBe(0);
  });

  it('is 0 at price = 1', () => {
    expect(kalshiTakerFee(1)).toBe(0);
  });

  it('peaks near price = 0.5 at 0.02 (2 cents), ceiled to the cent', () => {
    // raw = 0.07 * 0.5 * 0.5 = 0.0175 -> ceil to cent = 0.02
    expect(kalshiTakerFee(0.5)).toBeCloseTo(0.02, 5);
  });

  it('rounds up to the nearest cent, never down', () => {
    // raw = 0.07 * 0.1 * 0.9 = 0.0063 -> ceil to cent = 0.01
    expect(kalshiTakerFee(0.1)).toBeCloseTo(0.01, 5);
  });

  it('is symmetric around price = 0.5', () => {
    expect(kalshiTakerFee(0.2)).toBeCloseTo(kalshiTakerFee(0.8), 5);
  });
});

describe('polymarketTakerFee', () => {
  it('is 0 at price = 0 or 1 regardless of category', () => {
    expect(polymarketTakerFee(0, 'crypto')).toBe(0);
    expect(polymarketTakerFee(1, 'crypto')).toBe(0);
  });

  it('geopolitics category is fee-free at any price', () => {
    expect(polymarketTakerFee(0.5, 'geopolitics')).toBe(0);
  });

  it('scales with the category constant k (crypto > politics > sports)', () => {
    const p = 0.5;
    expect(polymarketTakerFee(p, 'crypto')).toBeGreaterThan(polymarketTakerFee(p, 'politics'));
    expect(polymarketTakerFee(p, 'politics')).toBeGreaterThan(polymarketTakerFee(p, 'sports'));
  });

  it('falls back to the general rate for an unknown category', () => {
    // @ts-expect-error - deliberately passing an invalid category to test the fallback
    expect(polymarketTakerFee(0.5, 'not-a-category')).toBeCloseTo(polymarketTakerFee(0.5, 'general'), 10);
  });

  it('peaks at price = 0.5 where fee = k / 4', () => {
    expect(polymarketTakerFee(0.5, 'politics')).toBeCloseTo(0.01 / 4, 10);
  });
});

describe('totalFees', () => {
  it('sums the correct fee function per venue', () => {
    const legA = { price: 0.5, venue: 'kalshi' };
    const legB = { price: 0.5, venue: 'polymarket', category: 'politics' as const };
    expect(totalFees(legA, legB)).toBeCloseTo(kalshiTakerFee(0.5) + polymarketTakerFee(0.5, 'politics'), 10);
  });
});
